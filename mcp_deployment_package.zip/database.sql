
CREATE TABLE mcp_users (id UUID PRIMARY KEY, email TEXT, role TEXT, api_key TEXT);
CREATE TABLE mcp_logs (id UUID PRIMARY KEY, request JSONB, response JSONB, created_at TIMESTAMP);
CREATE TABLE mcp_service_mapping (id UUID PRIMARY KEY, intent TEXT, services JSONB);
